create or replace function public.get_merchant_quick_analytics(p_merchant_id uuid)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_month_start timestamptz := date_trunc('month', current_date);
  v_gross_sales numeric := 0;
  v_total_costs numeric := 0;
  v_pending_debts numeric := 0;
  v_net_profit numeric := 0;
  v_peak_hour text;
  v_peak_hours json;
begin
  select coalesce(sum(s.amount), 0), coalesce(sum(s.cost), 0)
    into v_gross_sales, v_total_costs
  from public.sales s
  where s.merchant_id = p_merchant_id
    and s.created_at >= v_month_start;

  select coalesce(sum(d.amount), 0)
    into v_pending_debts
  from public.debts d
  where d.merchant_id = p_merchant_id
    and d.status = 'pending'
    and d.created_at >= v_month_start;

  v_net_profit := v_gross_sales - v_total_costs - v_pending_debts;

  select to_char(s.created_at, 'HH12:00 AM')
    into v_peak_hour
  from public.sales s
  where s.merchant_id = p_merchant_id
    and s.created_at >= v_month_start
  group by to_char(s.created_at, 'HH12:00 AM')
  order by count(*) desc, min(s.created_at)
  limit 1;

  select coalesce(json_agg(hour_row order by hour_row.hour), '[]'::json)
    into v_peak_hours
  from (
    select extract(hour from s.created_at)::int as hour,
           to_char(s.created_at, 'HH12:00 AM') as label,
           count(*)::int as sales_count
    from public.sales s
    where s.merchant_id = p_merchant_id
      and s.created_at >= v_month_start
    group by extract(hour from s.created_at), to_char(s.created_at, 'HH12:00 AM')
  ) as hour_row;

  return json_build_object(
    'gross_sales', v_gross_sales,
    'total_costs', v_total_costs,
    'pending_debts', v_pending_debts,
    'net_profit', v_net_profit,
    'peak_hour', coalesce(v_peak_hour, 'لا توجد بيانات كافية'),
    'peak_hours', v_peak_hours
  );
end;
$$;

grant execute on function public.get_merchant_quick_analytics(uuid) to authenticated;
