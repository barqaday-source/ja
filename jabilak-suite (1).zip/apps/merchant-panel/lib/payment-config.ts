import { getAdminSettings, type AdminPromotionalPlan } from "@/lib/admin-settings";

export type PromotionalPlan = AdminPromotionalPlan;

export const PAYMENT_ACCOUNT = getAdminSettings().payment;
export const PROMOTIONAL_PLANS = getAdminSettings().promotionalPlans;

export type LocalPaymentMethod = "okx" | "cash_on_delivery" | "zain_cash" | "asia_hawala";

export const LOCAL_PAYMENT_METHODS: Array<{ id: LocalPaymentMethod; label: string; description: string; available: boolean }> = [
  { id: "cash_on_delivery", label: "الدفع عند الاستلام", description: "ادفع عند وصول الطلب", available: true },
  { id: "zain_cash", label: "زين كاش", description: "تحويل عبر محفظة زين كاش", available: true },
  { id: "asia_hawala", label: "آسيا حوالة", description: "تحويل عبر محفظة آسيا حوالة", available: true },
  { id: "okx", label: "OKX", description: "دفع رقمي عبر OKX", available: true },
];

export function getPromotionalPlan(days: number) {
  return PROMOTIONAL_PLANS.find((plan) => plan.days === days) ?? PROMOTIONAL_PLANS[0];
}

export function formatPromotionalAmount(plan: PromotionalPlan) {
  return plan.currency === "USD"
    ? `$${plan.amount.toLocaleString("en-US")}`
    : `${plan.amount.toLocaleString("en-US")} د.ع`;
}
