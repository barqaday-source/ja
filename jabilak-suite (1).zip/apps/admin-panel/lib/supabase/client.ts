import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

/**
 * Returns a browser/mobile-safe client only when the public Supabase settings exist.
 * Never put a service_role key in the Expo bundle.
 */
export const supabase: SupabaseClient | null = url && anonKey
  ? createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: false,
      },
    })
  : null;

export const isSupabaseConfigured = Boolean(supabase);

export function requireSupabase(): SupabaseClient {
  if (!supabase) {
    throw new Error("Supabase غير مهيأ: أضف EXPO_PUBLIC_SUPABASE_URL وEXPO_PUBLIC_SUPABASE_ANON_KEY أولاً.");
  }
  return supabase;
}
