import { useCallback, useState } from "react";
export function useMockAction(delayMs = 650) {
  const [busy, setBusy] = useState(false);
  const run = useCallback(async <T,>(action: () => T | Promise<T>) => {
    if (busy) return undefined;
    setBusy(true);
    try { return await action(); } finally { setBusy(false); }
  }, [busy]);
  return { busy, run };
}
