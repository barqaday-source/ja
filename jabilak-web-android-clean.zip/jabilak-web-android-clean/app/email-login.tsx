import { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function EmailLoginScreen() {
  const router = useRouter();
  const colors = useColors();
  const params = useLocalSearchParams<{ role?: string }>();
  const [email, setEmail] = useState("");
  const [focused, setFocused] = useState(false);

  const submit = () => {
    const value = email.trim();
    if (!value || !value.includes("@")) {
      Alert.alert("تحقق من البريد الإلكتروني", "أدخل بريداً إلكترونياً صحيحاً للمتابعة.");
      return;
    }
    Alert.alert("تم إرسال رابط الدخول", "تحقق من بريدك الإلكتروني واضغط الرابط للعودة إلى التطبيق.");
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} className="px-5">
      <View style={styles.content}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, { opacity: pressed ? 0.55 : 1 }]}><MaterialIcons name="arrow-forward" size={22} color={colors.foreground} /></Pressable>
        <View style={[styles.icon, { backgroundColor: `${colors.primary}15` }]}><MaterialIcons name="mail-outline" size={31} color={colors.primary} /></View>
        <Text style={[styles.kicker, { color: colors.primary }]}>دخول سريع وآمن</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>أدخل بريدك الإلكتروني</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>سنرسل لك رابط دخول مباشر. لا تحتاج إلى كلمة مرور أو تأكيد إضافي.</Text>

        <View style={styles.form}>
          <Text style={[styles.label, { color: colors.foreground }]}>البريد الإلكتروني</Text>
          <View style={[styles.inputWrap, { backgroundColor: colors.surface, borderColor: focused ? colors.primary : colors.border }]}>
            <MaterialIcons name="alternate-email" size={20} color={focused ? colors.primary : colors.muted} />
            <TextInput value={email} onChangeText={setEmail} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} placeholder="name@example.com" placeholderTextColor={colors.muted} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} style={[styles.input, { color: colors.foreground }]} returnKeyType="done" onSubmitEditing={submit} />
          </View>
          <Text style={[styles.helper, { color: colors.muted }]}>طريقة الاستخدام: {params.role === "merchant" ? "تاجر" : "زبون"}</Text>
        </View>

        <View style={styles.footer}>
          <Pressable onPress={submit} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 }]}><Text style={styles.primaryText}>إرسال رابط الدخول</Text><MaterialIcons name="arrow-back" size={20} color="#FFFFFF" /></Pressable>
          <Text style={[styles.privacy, { color: colors.muted }]}>بمتابعة الدخول، أنت توافق على شروط الاستخدام وسياسة الخصوصية.</Text>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { flex: 1, paddingTop: 8, paddingBottom: 18 },
  back: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", alignSelf: "flex-end" },
  icon: { width: 70, height: 70, borderRadius: 24, alignItems: "center", justifyContent: "center", alignSelf: "flex-end", marginTop: 45 },
  kicker: { fontSize: 13, fontWeight: "900", textAlign: "right", marginTop: 24 },
  title: { fontSize: 30, fontWeight: "900", lineHeight: 41, textAlign: "right", marginTop: 8 },
  subtitle: { fontSize: 14, lineHeight: 23, textAlign: "right", marginTop: 12 },
  form: { marginTop: 38 },
  label: { fontSize: 13, fontWeight: "900", textAlign: "right", marginBottom: 9 },
  inputWrap: { minHeight: 56, borderWidth: 1.5, borderRadius: 17, paddingHorizontal: 15, flexDirection: "row-reverse", alignItems: "center", gap: 9 },
  input: { flex: 1, fontSize: 15, textAlign: "right", paddingVertical: 3 },
  helper: { fontSize: 11, textAlign: "right", marginTop: 9 },
  footer: { marginTop: "auto", gap: 14 },
  primaryButton: { minHeight: 56, borderRadius: 18, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 12 },
  primaryText: { color: "#FFFFFF", fontSize: 15, fontWeight: "900" },
  privacy: { fontSize: 10, lineHeight: 16, textAlign: "center", paddingHorizontal: 12 },
});
