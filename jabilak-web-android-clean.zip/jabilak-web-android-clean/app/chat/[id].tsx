import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useI18n } from "@/lib/i18n";
import { getChatById, MOCK_MESSAGES, type ChatMessage } from "@/lib/chat/mock";
import { buildWhatsAppBookingUrl, searchShoppingProducts, type ShoppingOutfit, type ShoppingProduct } from "@/lib/search/product-search";
import { loadAbuAlEreefSession, saveAbuAlEreefSession } from "@/lib/chat/abu-al-ereef-session";

export default function ChatScreen() {
  const colors = useColors();
  const { t } = useI18n();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const chat = useMemo(() => getChatById(String(id ?? "alanaqa")), [id]);
  const [messages, setMessages] = useState<ChatMessage[]>(() => [...(MOCK_MESSAGES[chat.id] ?? [])]);
  const [sessionReady, setSessionReady] = useState(chat.id !== "abu-arif");
  const [draft, setDraft] = useState("");
  const [recording, setRecording] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [typing, setTyping] = useState(false);
  const [assistantSearching, setAssistantSearching] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [actionMessage, setActionMessage] = useState<ChatMessage | null>(null);
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null);
  const [editText, setEditText] = useState("");
  const [pendingDeleteMessage, setPendingDeleteMessage] = useState<ChatMessage | null>(null);
  const messagesScrollRef = useRef<FlatList<ChatMessage>>(null);

  useEffect(() => {
    if (chat.id !== "abu-arif") return;
    let active = true;
    setSessionReady(false);
    void loadAbuAlEreefSession().then((saved) => {
      if (!active) return;
      if (saved) setMessages(saved);
      setSessionReady(true);
    });
    return () => { active = false; };
  }, [chat.id]);

  useEffect(() => {
    if (chat.id === "abu-arif" && sessionReady) void saveAbuAlEreefSession(messages);
  }, [chat.id, messages, sessionReady]);

  useEffect(() => {
    const timer = setTimeout(() => messagesScrollRef.current?.scrollToEnd({ animated: true }), 0);
    return () => clearTimeout(timer);
  }, [messages.length]);

  const sendText = () => {
    const text = draft.trim();
    if (!text) return;
    setMessages((current) => [...current, { id: `local-${Date.now()}`, sender: "me", kind: "text", text, time: "الآن", read: false }]);
    setDraft("");
    if (chat.id === "abu-arif") {
      setAssistantSearching(true);
      void searchShoppingProducts(text).then((result) => {
        const summary = result.products.length
          ? `لكيت لك ${result.products.length} ${result.products.length === 1 ? "منتج" : "منتجات"} متوفرة${result.parsed.maxPrice ? ` ضمن ${result.parsed.maxPrice.toLocaleString("en-US")} د.ع` : ""}.`
          : "ما لگيت نتيجة مطابقة هالمرة. جرّب تكتب اسم المنتج ويا اللون أو خلي السعر أعلى شويّة، وأنا أدوّر لك من جديد.";
        setMessages((current) => [...current, { id: `abu-reply-${Date.now()}`, sender: "them", kind: result.products.length ? "product_results" : "text", text: summary, products: result.products, outfits: result.outfits, time: "الآن", read: true }]);
      }).catch(() => {
        setMessages((current) => [...current, { id: `abu-error-${Date.now()}`, sender: "them", kind: "text", text: "صار خلل بسيط بالبحث. جرّب مرة ثانية بعد لحظات.", time: "الآن", read: true }]);
      }).finally(() => setAssistantSearching(false));
      return;
    }
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMessages((current) => [...current, { id: `reply-${Date.now()}`, sender: "them", kind: "text", text: "وصلت رسالتك، سأرد عليك حالاً.", time: "الآن", read: true }]);
    }, 850);
  };

  const pickPhoto = async () => {
    setUploading(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: false, quality: 0.85 });
      if (!result.canceled && result.assets[0]?.uri) {
        await new Promise((resolve) => setTimeout(resolve, 350));
        setMessages((current) => [...current, { id: `image-${Date.now()}`, sender: "me", kind: "image", uri: result.assets[0].uri, mimeType: result.assets[0].mimeType, fileSize: result.assets[0].fileSize, time: "الآن", read: false }]);
      }
    } catch {
      Alert.alert("تعذر إرفاق الصورة", "تحقق من صلاحية الوصول إلى الصور ثم حاول مرة أخرى.");
    } finally {
      setUploading(false);
    }
  };

  const pickFile = async () => {
    setUploading(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: "*/*", copyToCacheDirectory: true, multiple: false });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        await new Promise((resolve) => setTimeout(resolve, 350));
        setMessages((current) => [...current, { id: `file-${Date.now()}`, sender: "me", kind: "file", uri: asset.uri, fileName: asset.name, fileSize: asset.size, mimeType: asset.mimeType, time: "الآن", read: false }]);
      }
    } catch {
      Alert.alert("تعذر إرفاق الملف", "تحقق من صلاحية الوصول إلى الملفات ثم حاول مرة أخرى.");
    } finally {
      setUploading(false);
    }
  };

  const openAttachment = async (uri: string) => {
    try {
      await Linking.openURL(uri);
    } catch {
      Alert.alert("تعذر فتح المرفق", "لا يمكن فتح هذا المرفق على هذا الجهاز حالياً.");
    }
  };

  const openMessageActions = (message: ChatMessage) => setActionMessage(message);
  const openEditMessage = (message: ChatMessage) => { setActionMessage(null); setEditingMessage(message); setEditText(message.text ?? ""); };
  const requestDeleteMessage = (message: ChatMessage) => { setActionMessage(null); setPendingDeleteMessage(message); };
  const confirmDeleteMessage = () => { if (!pendingDeleteMessage) return; setMessages((current) => current.filter((item) => item.id !== pendingDeleteMessage.id)); setPendingDeleteMessage(null); };
  const saveMessageEdit = () => { if (!editingMessage) return; const nextText = editText.trim(); setMessages((current) => current.map((item) => item.id === editingMessage.id ? { ...item, text: nextText || undefined } : item)); setEditingMessage(null); setEditText(""); };

  const toggleVoice = () => {
    if (!recording) {
      setRecording(true);
      return;
    }
    setRecording(false);
    setMessages((current) => [...current, { id: `voice-${Date.now()}`, sender: "me", kind: "voice", duration: "0:12", time: "الآن", read: false }]);
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}>
        <View style={[styles.header, { backgroundColor: colors.surface, borderColor: colors.border }]}><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.back, { borderColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="arrow-forward" size={21} color={colors.foreground} /></Pressable><View style={styles.headerAvatarWrap}>{chat.role === "assistant" ? <View style={[styles.assistantAvatar, { backgroundColor: colors.primary }]}><IconSymbol name="abu-al-ereef" size={24} color="#FFFFFF" /></View> : <Image source={{ uri: chat.avatar }} style={styles.headerAvatar} />}{chat.online && <View style={[styles.onlineDot, { backgroundColor: colors.success, borderColor: colors.surface }]} />}</View><View style={styles.headerCopy}><Text style={[styles.headerName, { color: colors.foreground }]} numberOfLines={1}>{chat.name}</Text><Text style={[styles.headerStatus, { color: chat.online ? colors.success : colors.muted }]}>{chat.online ? t("connectedNow") : t("lastSeenRecently")}</Text></View><View style={styles.headerActions}><Pressable onPress={() => router.push({ pathname: "/call/[id]", params: { id: chat.id, type: "voice" } })} style={({ pressed }) => [styles.headerAction, { backgroundColor: `${colors.primary}15`, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="call" size={19} color={colors.primary} /></Pressable><Pressable onPress={() => setInfoOpen(true)} style={({ pressed }) => [styles.headerAction, { backgroundColor: `${colors.primary}15`, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="info-outline" size={19} color={colors.primary} /></Pressable></View></View>

        <View style={[styles.encryption, { backgroundColor: `${colors.success}10` }]}><MaterialIcons name="lock-outline" size={14} color={colors.success} /><Text style={[styles.encryptionText, { color: colors.success }]}>{t("privateChat")} · {t("readyForEncryption")}</Text></View>

        <Modal visible={infoOpen} transparent animationType="slide" onRequestClose={() => setInfoOpen(false)}><Pressable style={styles.infoBackdrop} onPress={() => setInfoOpen(false)}><Pressable onPress={(event) => event.stopPropagation()} style={[styles.infoSheet, { backgroundColor: colors.surface }]}><View style={styles.sheetHandle} /><View style={styles.infoProfile}>{chat.role === "assistant" ? <View style={[styles.infoAvatar, styles.assistantInfoAvatar, { backgroundColor: colors.primary }]}><IconSymbol name="abu-al-ereef" size={34} color="#FFFFFF" /></View> : <Image source={{ uri: chat.avatar }} style={styles.infoAvatar } />}<Text style={[styles.infoName, { color: colors.foreground }]}>{chat.name}</Text><Text style={[styles.infoStatus, { color: chat.online ? colors.success : colors.muted }]}>{chat.online ? "متصل الآن" : "آخر ظهور مؤخراً"}</Text></View><View style={[styles.infoSecure, { backgroundColor: `${colors.success}10`, borderColor: `${colors.success}35` }]}><MaterialIcons name="lock-outline" size={18} color={colors.success} /><View style={styles.infoSecureCopy}><Text style={[styles.infoSecureTitle, { color: colors.foreground }]}>محادثة خاصة</Text><Text style={[styles.infoSecureText, { color: colors.muted }]}>هذه المحادثة بينك وبين هذا الطرف فقط، ومهيأة للتشفير عند الربط الفعلي.</Text></View></View><View style={[styles.infoOption, { borderBottomColor: colors.border }]}><View style={styles.infoOptionCopy}><Text style={[styles.infoOptionTitle, { color: colors.foreground }]}>كتم الإشعارات</Text><Text style={[styles.infoOptionText, { color: colors.muted }]}>{muted ? "لن تظهر تنبيهات هذه المحادثة" : "ستظهر تنبيهات الرسائل الجديدة"}</Text></View><Switch value={muted} onValueChange={setMuted} trackColor={{ false: colors.border, true: `${colors.primary}75` }} thumbColor={muted ? colors.primary : colors.muted} /></View><Pressable onPress={() => { setInfoOpen(false); Alert.alert("الملفات المشتركة", "سيظهر هنا معرض الصور والملفات بعد ربط التخزين."); }} style={({ pressed }) => [styles.infoAction, { borderBottomColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="photo-library" size={19} color={colors.primary} /><Text style={[styles.infoActionText, { color: colors.foreground }]}>الملفات والصور المشتركة</Text><MaterialIcons name="chevron-left" size={19} color={colors.muted} /></Pressable><Pressable onPress={() => setInfoOpen(false)} style={({ pressed }) => [styles.infoClose, { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 }]}><Text style={styles.infoCloseText}>إغلاق</Text></Pressable></Pressable></Pressable></Modal>

        <Modal visible={actionMessage !== null} transparent animationType="fade" onRequestClose={() => setActionMessage(null)}><Pressable style={styles.actionBackdrop} onPress={() => setActionMessage(null)}><Pressable onPress={(event) => event.stopPropagation()} style={[styles.actionSheet, { backgroundColor: colors.surface }]}><View style={styles.sheetHandle} /><Text style={[styles.actionTitle, { color: colors.foreground }]}>إجراءات الرسالة</Text><Text style={[styles.actionHint, { color: colors.muted }]}>{actionMessage?.kind === "text" ? "رسالة نصية" : actionMessage?.kind === "image" ? "صورة" : actionMessage?.kind === "file" ? "ملف" : "تسجيل صوتي"}</Text><Pressable onPress={() => actionMessage && openEditMessage(actionMessage)} style={({ pressed }) => [styles.actionOption, { borderBottomColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="edit" size={19} color={colors.primary} /><Text style={[styles.actionOptionText, { color: colors.foreground }]}>تعديل الرسالة أو وصف المرفق</Text></Pressable><Pressable onPress={() => actionMessage && requestDeleteMessage(actionMessage)} style={({ pressed }) => [styles.actionOption, { borderBottomColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="delete-outline" size={19} color={colors.error} /><Text style={[styles.actionOptionText, { color: colors.error }]}>حذف الرسالة</Text></Pressable><Pressable onPress={() => setActionMessage(null)} style={({ pressed }) => [styles.actionClose, { backgroundColor: colors.background, opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.actionCloseText, { color: colors.foreground }]}>إلغاء</Text></Pressable></Pressable></Pressable></Modal>
        <Modal visible={editingMessage !== null} transparent animationType="slide" onRequestClose={() => setEditingMessage(null)}><Pressable style={styles.actionBackdrop} onPress={() => setEditingMessage(null)}><Pressable onPress={(event) => event.stopPropagation()} style={[styles.editMessageSheet, { backgroundColor: colors.surface }]}><View style={styles.sheetHandle} /><Text style={[styles.actionTitle, { color: colors.foreground }]}>تعديل الرسالة</Text><Text style={[styles.actionHint, { color: colors.muted }]}>يمكن تعديل النص أو إضافة وصف للصورة والملف والصوت.</Text><TextInput value={editText} onChangeText={setEditText} multiline placeholder="اكتب تعديلك هنا" placeholderTextColor={colors.muted} textAlign="right" style={[styles.editMessageInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]} /><View style={styles.actionButtons}><Pressable onPress={() => setEditingMessage(null)} style={({ pressed }) => [styles.actionCancel, { borderColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><Text style={[styles.actionCancelText, { color: colors.foreground }]}>إلغاء</Text></Pressable><Pressable onPress={saveMessageEdit} style={({ pressed }) => [styles.actionSave, { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 }]}><Text style={styles.actionSaveText}>حفظ التعديل</Text></Pressable></View></Pressable></Pressable></Modal>
        <Modal visible={pendingDeleteMessage !== null} transparent animationType="fade" onRequestClose={() => setPendingDeleteMessage(null)}><Pressable style={styles.actionBackdrop} onPress={() => setPendingDeleteMessage(null)}><Pressable onPress={(event) => event.stopPropagation()} style={[styles.confirmMessageSheet, { backgroundColor: colors.surface }]}><View style={[styles.confirmMessageIcon, { backgroundColor: `${colors.error}12` }]}><MaterialIcons name="delete-outline" size={25} color={colors.error} /></View><Text style={[styles.actionTitle, { color: colors.foreground }]}>حذف الرسالة</Text><Text style={[styles.actionHint, { color: colors.muted }]}>سيتم حذف {pendingDeleteMessage?.kind === "text" ? "النص" : pendingDeleteMessage?.kind === "image" ? "الصورة" : pendingDeleteMessage?.kind === "file" ? "الملف" : "التسجيل الصوتي"} من هذه المحادثة. لا يمكن التراجع عن هذا الإجراء.</Text><View style={styles.actionButtons}><Pressable onPress={() => setPendingDeleteMessage(null)} style={({ pressed }) => [styles.actionCancel, { borderColor: colors.border, opacity: pressed ? 0.65 : 1 }]}><Text style={[styles.actionCancelText, { color: colors.foreground }]}>إلغاء</Text></Pressable><Pressable onPress={confirmDeleteMessage} style={({ pressed }) => [styles.actionSave, { backgroundColor: colors.error, opacity: pressed ? 0.75 : 1 }]}><Text style={styles.actionSaveText}>تأكيد الحذف</Text></Pressable></View></Pressable></Pressable></Modal>

<FlatList
          ref={messagesScrollRef}
          style={styles.messagesScroll}
          contentContainerStyle={styles.messages}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <MessageBubble message={item} colors={colors} onActions={openMessageActions} onOpenProduct={(product) => router.push({ pathname: "/product/[id]", params: { id: product.id } })} onOpenCompany={(companyId) => router.push({ pathname: "/shop/[id]", params: { id: companyId } })} onOpenAttachment={openAttachment} />}
          ListHeaderComponent={<View style={[styles.datePill, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.dateText, { color: colors.muted }]}>{t("today")}</Text></View>}
          ListFooterComponent={(typing || assistantSearching) ? <View style={styles.typingRow}><View style={[styles.typingBubble, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.dot, { backgroundColor: colors.muted }]} /><View style={[styles.dot, { backgroundColor: colors.muted }]} /><View style={[styles.dot, { backgroundColor: colors.muted }]} /></View><Text style={[styles.typingText, { color: colors.muted }]}>{assistantSearching ? "أبو العريف يدور لك..." : t("writingNow")}</Text></View> : null}
          initialNumToRender={18}
          maxToRenderPerBatch={12}
          updateCellsBatchingPeriod={40}
          windowSize={7}
          removeClippedSubviews={Platform.OS !== "web"}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        />

        <View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}><Pressable disabled={uploading} onPress={pickPhoto} style={({ pressed }) => [styles.composerAction, { backgroundColor: `${colors.primary}15`, opacity: uploading ? 0.65 : pressed ? 0.65 : 1 }]} accessibilityLabel="إرفاق صورة">{uploading ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialIcons name="photo-library" size={19} color={colors.primary} />}</Pressable><Pressable disabled={uploading} onPress={pickFile} style={({ pressed }) => [styles.composerAction, { backgroundColor: `${colors.primary}15`, opacity: uploading ? 0.65 : pressed ? 0.65 : 1 }]} accessibilityLabel="إرفاق ملف">{uploading ? <ActivityIndicator size="small" color={colors.primary} /> : <MaterialIcons name="attach-file" size={19} color={colors.primary} />}</Pressable><TextInput value={draft} onChangeText={setDraft} placeholder={recording ? t("voiceRecordingHint") : t("writeMessage")} placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]} multiline maxLength={500} /><Pressable onPress={toggleVoice} style={({ pressed }) => [styles.composerAction, { backgroundColor: recording ? `${colors.error}18` : `${colors.primary}15`, opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name={recording ? "stop" : "mic-none"} size={20} color={recording ? colors.error : colors.primary} /></Pressable><Pressable onPress={sendText} style={({ pressed }) => [styles.sendButton, { backgroundColor: draft.trim() ? colors.primary : colors.muted, opacity: pressed ? 0.7 : 1 }]}><MaterialIcons name="arrow-upward" size={19} color="#FFFFFF" /></Pressable></View>
        {uploading && <View style={[styles.uploadHint, { backgroundColor: `${colors.primary}10` }]}><ActivityIndicator size="small" color={colors.primary} /><Text style={[styles.uploadHintText, { color: colors.primary }]}>جارٍ تجهيز المرفق لإرساله...</Text></View>}
        {recording && <Text style={[styles.recordingHint, { color: colors.error }]}>{t("voiceRecordingHint")}</Text>}
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function fileTypeLabel(mimeType?: string, fileName?: string) {
  if (mimeType === "application/pdf" || fileName?.toLowerCase().endsWith(".pdf")) return "PDF";
  if (mimeType?.includes("spreadsheet") || /\.(xlsx?|csv)$/i.test(fileName ?? "")) return "مستند جدول";
  if (mimeType?.startsWith("image/")) return "صورة";
  if (mimeType?.startsWith("video/")) return "فيديو";
  return "ملف";
}

function formatFileSize(size?: number) {
  if (!size || size < 1) return "الحجم غير معروف";
  if (size < 1024) return `${size} بايت`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} ك.ب`;
  return `${(size / (1024 * 1024)).toFixed(1)} م.ب`;
}

function MessageBubble({ message, colors, onActions, onOpenProduct, onOpenCompany, onOpenAttachment }: { message: ChatMessage; colors: ReturnType<typeof useColors>; onActions: (message: ChatMessage) => void; onOpenProduct: (product: ShoppingProduct) => void; onOpenCompany: (companyId: string) => void; onOpenAttachment: (uri: string) => void }) {
  const mine = message.sender === "me";
  return <Pressable onPress={() => message.uri && onOpenAttachment(message.uri)} onLongPress={() => onActions(message)} delayLongPress={420} style={[styles.messageRow, mine ? styles.mineRow : styles.theirRow]}><View style={[styles.bubble, mine ? { backgroundColor: colors.primary, borderBottomRightRadius: 6 } : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderBottomLeftRadius: 6 }]}>{message.kind === "image" && message.uri ? <Image source={{ uri: message.uri }} style={styles.messageImage} /> : message.kind === "product_results" ? <ProductResultsCard products={message.products ?? []} outfits={message.outfits ?? []} colors={colors} onOpenProduct={onOpenProduct} onOpenCompany={onOpenCompany} /> : message.kind === "file" ? <View style={styles.fileMessage}><View style={[styles.fileIcon, { backgroundColor: mine ? "rgba(255,255,255,0.22)" : `${colors.primary}18` }]}><MaterialIcons name="insert-drive-file" size={18} color={mine ? "#FFFFFF" : colors.primary} /></View><View style={styles.fileCopy}><Text style={[styles.fileName, { color: mine ? "#FFFFFF" : colors.foreground }]} numberOfLines={1}>{message.fileName ?? "ملف مرفق"}</Text><Text style={[styles.fileMeta, { color: mine ? "rgba(255,255,255,0.72)" : colors.muted }]}>{fileTypeLabel(message.mimeType, message.fileName)} · {formatFileSize(message.fileSize)}</Text></View><MaterialIcons name="open-in-new" size={15} color={mine ? "#FFFFFF" : colors.primary} /></View> : message.kind === "voice" ? <View style={styles.voiceMessage}><View style={[styles.playCircle, { backgroundColor: mine ? "rgba(255,255,255,0.22)" : `${colors.primary}18` }]}><MaterialIcons name="play-arrow" size={18} color={mine ? "#FFFFFF" : colors.primary} /></View><View style={styles.wave}><View style={[styles.waveLine, { backgroundColor: mine ? "rgba(255,255,255,0.78)" : colors.primary }]} /><View style={[styles.waveLineShort, { backgroundColor: mine ? "rgba(255,255,255,0.58)" : `${colors.primary}78` }]} /><View style={[styles.waveLine, { backgroundColor: mine ? "rgba(255,255,255,0.78)" : colors.primary }]} /><View style={[styles.waveLineTiny, { backgroundColor: mine ? "rgba(255,255,255,0.55)" : `${colors.primary}70` }]} /></View><Text style={[styles.duration, { color: mine ? "#FFFFFF" : colors.foreground }]}>{message.duration}</Text></View> : <Text style={[styles.messageText, { color: mine ? "#FFFFFF" : colors.foreground }]}>{message.text}</Text>}{message.text && message.kind !== "text" && <Text style={[styles.attachmentCaption, { color: mine ? "rgba(255,255,255,0.88)" : colors.foreground }]}>{message.text}</Text>}<View style={styles.bubbleMeta}><Text style={[styles.messageTime, { color: mine ? "rgba(255,255,255,0.68)" : colors.muted }]}>{message.time}</Text>{mine && <MaterialIcons name={message.read ? "done-all" : "done"} size={14} color={message.read ? "#CFF8E8" : "rgba(255,255,255,0.7)"} />}</View></View></Pressable>;
}

function ProductResultsCard({ products, outfits, colors, onOpenProduct, onOpenCompany }: { products: ShoppingProduct[]; outfits: ShoppingOutfit[]; colors: ReturnType<typeof useColors>; onOpenProduct: (product: ShoppingProduct) => void; onOpenCompany: (companyId: string) => void }) {
  return <View style={styles.productResults}><View style={styles.productResultsHeader}><MaterialIcons name="auto-awesome" size={17} color={colors.primary} /><Text style={[styles.productResultsTitle, { color: colors.foreground }]}>نتائج أبو العريف</Text></View>{products.map((product) => { const bookingUrl = buildWhatsAppBookingUrl(product); return <View key={product.id} style={[styles.assistantProduct, { backgroundColor: colors.background, borderColor: colors.border }]}><Pressable onPress={() => onOpenProduct(product)} style={({ pressed }) => [styles.assistantProductMain, { opacity: pressed ? 0.72 : 1 }]}><Image source={{ uri: product.imageUrl }} style={styles.assistantProductImage} /><View style={styles.assistantProductCopy}><Text style={[styles.assistantProductName, { color: colors.foreground }]} numberOfLines={1}>{product.name}</Text>{product.companyId ? <Pressable onPress={() => onOpenCompany(product.companyId!)} style={({ pressed }) => [styles.companyLink, { opacity: pressed ? 0.65 : 1 }]}><MaterialIcons name="storefront" size={13} color={colors.primary} /><Text style={[styles.assistantProductCompany, { color: colors.primary }]} numberOfLines={1}>{product.companyName}</Text></Pressable> : <Text style={[styles.assistantProductCompany, { color: colors.muted }]} numberOfLines={1}>{product.companyName}</Text>}<View style={styles.productBadgeRow}>{product.isSponsored && <View style={[styles.productBadge, { backgroundColor: `${colors.primary}18` }]}><MaterialIcons name="auto-awesome" size={11} color={colors.primary} /><Text style={[styles.productBadgeText, { color: colors.primary }]}>الأولوية الأولى · برعاية</Text></View>}{product.isVerified && <View style={[styles.productBadge, { backgroundColor: "rgba(37,99,235,0.12)" }]}><MaterialIcons name="verified" size={11} color="#2563EB" /><Text style={[styles.productBadgeText, { color: "#2563EB" }]}>موثق</Text></View>}</View><Text style={[styles.assistantProductPrice, { color: colors.primary }]}>{product.price.toLocaleString("en-US")} د.ع</Text><Text style={[styles.assistantProductStock, { color: colors.success }]}>متوفر الآن · {product.quantity} قطعة</Text>{product.location && <Text style={[styles.assistantProductLocation, { color: colors.muted }]}>{product.location}</Text>}</View></Pressable>{bookingUrl ? <Pressable onPress={() => void Linking.openURL(bookingUrl)} style={({ pressed }) => [styles.bookingButton, { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 }]}><MaterialIcons name="chat" size={16} color="#FFFFFF" /><Text style={styles.bookingButtonText}>احجز عبر WhatsApp</Text></Pressable> : <Text style={[styles.bookingUnavailable, { color: colors.muted }]}>التواصل سيضاف من إعدادات المتجر</Text>}</View>; })}{outfits.length > 0 && <View style={styles.outfitsSection}><View style={styles.outfitsHeader}><MaterialIcons name="style" size={16} color={colors.primary} /><Text style={[styles.productResultsTitle, { color: colors.foreground }]}>تنسيقات مقترحة لك</Text></View>{outfits.map((outfit) => <View key={outfit.id} style={[styles.outfitCard, { backgroundColor: colors.background, borderColor: colors.border }]}><View style={styles.outfitCopy}><Text style={[styles.outfitTitle, { color: colors.foreground }]}>{outfit.title}</Text><Text style={[styles.outfitDescription, { color: colors.muted }]}>{outfit.description}</Text><Text style={[styles.outfitTotal, { color: colors.primary }]}>الإجمالي {outfit.totalPrice.toLocaleString("en-US")} د.ع</Text></View><View style={styles.outfitProducts}>{outfit.products.map((product) => <Pressable key={product.id} onPress={() => onOpenProduct(product)} style={({ pressed }) => [styles.outfitProduct, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}><Image source={{ uri: product.imageUrl }} style={styles.outfitImage} /><Text style={[styles.outfitProductName, { color: colors.foreground }]} numberOfLines={1}>{product.name}</Text></Pressable>)}</View></View>)}</View>}</View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1 }, actionBackdrop: { flex: 1, backgroundColor: "rgba(17,24,39,0.48)", justifyContent: "flex-end" }, actionSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, paddingBottom: 30, gap: 10 }, editMessageSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, paddingBottom: 30, gap: 10 }, confirmMessageSheet: { borderRadius: 24, margin: 20, padding: 20, gap: 10 }, actionTitle: { fontSize: 18, fontWeight: "900", textAlign: "right" }, actionHint: { fontSize: 10, lineHeight: 18, textAlign: "right" }, actionOption: { minHeight: 52, borderBottomWidth: 1, flexDirection: "row-reverse", alignItems: "center", gap: 10 }, actionOptionText: { flex: 1, fontSize: 12, fontWeight: "800", textAlign: "right" }, actionClose: { minHeight: 46, borderRadius: 14, alignItems: "center", justifyContent: "center", marginTop: 4 }, actionCloseText: { fontSize: 11, fontWeight: "900" }, editMessageInput: { minHeight: 96, maxHeight: 150, borderWidth: 1, borderRadius: 14, padding: 12, textAlignVertical: "top", fontSize: 12 }, actionButtons: { flexDirection: "row-reverse", gap: 8, marginTop: 6 }, actionCancel: { flex: 1, minHeight: 46, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" }, actionCancelText: { fontSize: 11, fontWeight: "800" }, actionSave: { flex: 1.2, minHeight: 46, borderRadius: 14, alignItems: "center", justifyContent: "center" }, actionSaveText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" }, confirmMessageIcon: { width: 50, height: 50, borderRadius: 16, alignItems: "center", justifyContent: "center", alignSelf: "flex-end" }, infoBackdrop: { flex: 1, backgroundColor: "rgba(17,24,39,0.43)", justifyContent: "flex-end" }, infoSheet: { borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 20, paddingBottom: 28, gap: 14 }, sheetHandle: { width: 42, height: 4, borderRadius: 2, backgroundColor: "rgba(17,24,39,0.16)", alignSelf: "center", marginBottom: 2 }, infoProfile: { alignItems: "center", gap: 4 }, infoAvatar: { width: 72, height: 72, borderRadius: 24, marginBottom: 3 }, infoName: { fontSize: 18, fontWeight: "900" }, infoStatus: { fontSize: 10 }, infoSecure: { minHeight: 66, borderRadius: 17, borderWidth: 1, padding: 11, flexDirection: "row-reverse", alignItems: "center", gap: 10 }, infoSecureCopy: { flex: 1, alignItems: "flex-end", gap: 3 }, infoSecureTitle: { fontSize: 12, fontWeight: "900", textAlign: "right" }, infoSecureText: { fontSize: 9, lineHeight: 16, textAlign: "right" }, infoOption: { minHeight: 63, borderBottomWidth: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }, infoOptionCopy: { flex: 1, alignItems: "flex-end", gap: 3 }, infoOptionTitle: { fontSize: 12, fontWeight: "900" }, infoOptionText: { fontSize: 9, textAlign: "right" }, infoAction: { minHeight: 52, borderBottomWidth: 1, flexDirection: "row-reverse", alignItems: "center", gap: 10 }, infoActionText: { flex: 1, fontSize: 12, fontWeight: "800", textAlign: "right" }, infoClose: { minHeight: 47, borderRadius: 15, alignItems: "center", justifyContent: "center" }, infoCloseText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, header: { minHeight: 71, borderBottomWidth: 1, paddingHorizontal: 14, flexDirection: "row-reverse", alignItems: "center", gap: 9 }, back: { width: 39, height: 39, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" }, headerAvatarWrap: { width: 45, height: 45, position: "relative" }, headerAvatar: { width: 45, height: 45, borderRadius: 16 }, assistantAvatar: { width: 45, height: 45, borderRadius: 16, alignItems: "center", justifyContent: "center" }, assistantInfoAvatar: { alignItems: "center", justifyContent: "center" }, onlineDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 2, position: "absolute", left: -2, bottom: -1 }, headerCopy: { flex: 1, alignItems: "flex-end" }, headerName: { fontSize: 13, fontWeight: "900", maxWidth: "100%" }, headerStatus: { fontSize: 9, marginTop: 4 }, headerActions: { flexDirection: "row-reverse", gap: 6 }, headerAction: { width: 35, height: 35, borderRadius: 12, alignItems: "center", justifyContent: "center" }, encryption: { minHeight: 29, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 5 }, encryptionText: { fontSize: 9, fontWeight: "800" }, messagesScroll: { flex: 1, minHeight: 0 }, messages: { padding: 16, paddingBottom: 22, gap: 10 }, datePill: { alignSelf: "center", borderWidth: 1, borderRadius: 10, paddingVertical: 5, paddingHorizontal: 12, marginBottom: 5 }, dateText: { fontSize: 9, fontWeight: "800" }, messageRow: { flexDirection: "row", width: "100%" }, mineRow: { justifyContent: "flex-start" }, theirRow: { justifyContent: "flex-end" }, bubble: { maxWidth: "82%", paddingHorizontal: 12, paddingTop: 9, paddingBottom: 7, borderRadius: 18, gap: 5 },   messageText: { fontSize: 12, lineHeight: 20, textAlign: "right" }, productResults: { gap: 9, minWidth: 280 }, outfitsSection: { gap: 8, marginTop: 2 }, outfitsHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 6 }, outfitCard: { borderWidth: 1, borderRadius: 16, padding: 9, gap: 9 }, outfitCopy: { alignItems: "flex-end", gap: 2 }, outfitTitle: { fontSize: 11, fontWeight: "900", textAlign: "right" }, outfitDescription: { fontSize: 9, textAlign: "right" }, outfitTotal: { fontSize: 10, fontWeight: "900" }, outfitProducts: { flexDirection: "row-reverse", gap: 7 }, outfitProduct: { width: 76, borderWidth: 1, borderRadius: 12, padding: 4, gap: 3 }, outfitImage: { width: 66, height: 58, borderRadius: 9 }, outfitProductName: { fontSize: 8, fontWeight: "800", textAlign: "right" }, productResultsHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 6, marginBottom: 2 }, productResultsTitle: { fontSize: 12, fontWeight: "900", textAlign: "right" }, assistantProduct: { borderWidth: 1, borderRadius: 16, padding: 8, gap: 8, minWidth: 270 }, assistantProductMain: { flexDirection: "row-reverse", alignItems: "center", gap: 9 }, assistantProductImage: { width: 62, height: 62, borderRadius: 13, backgroundColor: "#E5E7EB" }, assistantProductCopy: { flex: 1, alignItems: "flex-end", gap: 2 }, assistantProductName: { fontSize: 11, fontWeight: "900", textAlign: "right" }, companyLink: { flexDirection: "row-reverse", alignItems: "center", gap: 4 }, assistantProductCompany: { fontSize: 9, textAlign: "right" }, assistantProductPrice: { fontSize: 11, fontWeight: "900" }, assistantProductStock: { fontSize: 8, fontWeight: "800" }, productBadgeRow: { flexDirection: "row-reverse", flexWrap: "wrap", justifyContent: "flex-start", gap: 4 }, productBadge: { flexDirection: "row-reverse", alignItems: "center", gap: 3, borderRadius: 6, paddingHorizontal: 5, paddingVertical: 3 }, productBadgeText: { fontSize: 7, fontWeight: "900" }, assistantProductLocation: { fontSize: 8, textAlign: "right" }, bookingButton: { minHeight: 34, borderRadius: 10, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 5 }, bookingButtonText: { color: "#FFFFFF", fontSize: 9, fontWeight: "900" }, bookingUnavailable: { fontSize: 9, textAlign: "center" }, messageImage: { width: 190, height: 150, borderRadius: 13 }, fileMessage: { minWidth: 205, flexDirection: "row-reverse", alignItems: "center", gap: 8 }, fileIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" }, fileCopy: { flex: 1, minWidth: 0, gap: 2 }, fileName: { maxWidth: 145, fontSize: 11, fontWeight: "800" }, fileMeta: { fontSize: 8 }, attachmentCaption: { fontSize: 10, lineHeight: 17, textAlign: "right" }, bubbleMeta: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "flex-start", gap: 3 }, messageTime: { fontSize: 8 }, voiceMessage: { minWidth: 176, flexDirection: "row-reverse", alignItems: "center", gap: 8 }, playCircle: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" }, wave: { flex: 1, flexDirection: "row-reverse", alignItems: "center", gap: 3 }, waveLine: { width: 3, height: 22, borderRadius: 2 }, waveLineShort: { width: 3, height: 13, borderRadius: 2 }, waveLineTiny: { width: 3, height: 8, borderRadius: 2 }, duration: { fontSize: 10, fontWeight: "900" }, typingRow: { flexDirection: "row-reverse", alignItems: "center", gap: 6, alignSelf: "flex-end" }, typingBubble: { flexDirection: "row-reverse", alignItems: "center", gap: 3, borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 11 }, dot: { width: 5, height: 5, borderRadius: 3 }, typingText: { fontSize: 9 }, composer: { minHeight: 63, borderTopWidth: 1, paddingHorizontal: 10, paddingVertical: 9, flexDirection: "row-reverse", alignItems: "flex-end", gap: 6 }, composerAction: { width: 38, height: 38, borderRadius: 14, alignItems: "center", justifyContent: "center" }, input: { flex: 1, minHeight: 40, maxHeight: 100, borderRadius: 15, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 9, textAlign: "right", fontSize: 12 }, sendButton: { width: 39, height: 39, borderRadius: 15, alignItems: "center", justifyContent: "center" }, recordingHint: { textAlign: "center", fontSize: 9, fontWeight: "800", paddingBottom: 5 }, uploadHint: { minHeight: 29, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 }, uploadHintText: { fontSize: 9, fontWeight: "800" },
});
