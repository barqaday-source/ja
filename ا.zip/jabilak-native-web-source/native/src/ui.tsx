import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { colors, spacing, typography } from './theme';

export function Screen({ children }: { children: React.ReactNode }) {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.screen}>{children}</View>
    </SafeAreaView>
  );
}
export function Header({
  title,
  onBack,
}: {
  title: string;
  onBack?: () => void;
}) {
  return (
    <View style={styles.header}>
      {onBack ? (
        <Pressable onPress={onBack} style={styles.round}>
          <Text style={styles.back}>‹</Text>
        </Pressable>
      ) : (
        <View style={styles.round} />
      )}
      <Text style={styles.headerTitle}>{title}</Text>
      <View style={[styles.round, styles.avatar]}>
        <Text style={styles.avatarText}>ج</Text>
      </View>
    </View>
  );
}
export function EmptyState({
  title,
  detail,
}: {
  title: string;
  detail: string;
}) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyDetail}>{detail}</Text>
    </View>
  );
}
export function LoadingState() {
  return (
    <View style={styles.empty}>
      <ActivityIndicator color={colors.primary} />
      <Text style={styles.emptyDetail}>جارٍ تحميل البيانات...</Text>
    </View>
  );
}
export function ActionButton({
  label,
  onPress,
}: {
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.action, pressed && styles.pressed]}
    >
      <Text style={styles.actionText}>{label}</Text>
      <View style={styles.actionIcon}>
        <Text style={styles.actionArrow}>‹</Text>
      </View>
    </Pressable>
  );
}
export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  screen: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: spacing.page,
  },
  header: {
    height: 88,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: {
    fontSize: typography.title,
    fontWeight: '700',
    color: colors.primary,
  },
  round: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  back: { fontSize: 27, color: colors.primary, lineHeight: 30 },
  avatar: { backgroundColor: colors.primary },
  avatarText: { color: colors.surface, fontSize: 16, fontWeight: '700' },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    gap: 10,
  },
  emptyTitle: {
    color: colors.primary,
    fontSize: typography.title,
    fontWeight: '700',
    textAlign: 'center',
  },
  emptyDetail: {
    color: colors.muted,
    fontSize: typography.body,
    textAlign: 'center',
    lineHeight: 22,
  },
  action: {
    height: 56,
    borderRadius: 100,
    backgroundColor: colors.primary,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 8,
    paddingRight: 24,
    marginVertical: 12,
  },
  actionText: {
    color: colors.surface,
    fontSize: typography.label,
    fontWeight: '500',
    flex: 1,
    textAlign: 'center',
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionArrow: { color: colors.primary, fontSize: 26, lineHeight: 28 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
});
