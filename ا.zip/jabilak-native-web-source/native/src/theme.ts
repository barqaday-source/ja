export const colors = {
  primary: '#0F0F11',
  background: '#F8F6F2',
  surface: '#FFFFFF',
  muted: '#6D757D',
  inactive: '#F1F3F5',
  border: '#E5E7EB',
  danger: '#B44242',
};

export const spacing = { page: 24, card: 24, gap: 8 } as const;
export const typography = {
  hero: 36,
  title: 20,
  price: 18,
  body: 14,
  label: 13,
} as const;
