import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { supabase } from './src/supabase';
import { colors, spacing, typography } from './src/theme';
import {
  ActionButton,
  EmptyState,
  Header,
  LoadingState,
  Screen,
} from './src/ui';

type Role = 'customer' | 'merchant' | 'admin';
type SessionProfile = {
  id: string;
  display_name: string;
  role: Role;
  avatar_url?: string | null;
};
type Company = {
  id: string;
  name: string;
  category?: string | null;
  province?: string | null;
  district?: string | null;
  logo_url?: string | null;
  cover_url?: string | null;
};
type Product = {
  id: string;
  name: string;
  price: number;
  category?: string | null;
  company_id: string;
  publication_status: string;
};
type RootStackParamList = {
  Customer: undefined;
  Merchant: undefined;
  Admin: undefined;
};
type CustomerTabs = {
  الرئيسية: undefined;
  استكشف: undefined;
  الرسائل: undefined;
  المخزون: undefined;
  حسابي: undefined;
};
const Root = createNativeStackNavigator<RootStackParamList>();
const Tabs = createBottomTabNavigator<CustomerTabs>();

function AuthScreen({
  onAuthenticated,
}: {
  onAuthenticated: (profile: SessionProfile) => void;
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    if (!email.trim() || !password)
      return Alert.alert('بيانات ناقصة', 'أدخل البريد وكلمة المرور للمتابعة.');
    setBusy(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error || !data.user) {
      setBusy(false);
      return Alert.alert(
        'تعذر تسجيل الدخول',
        error?.message ?? 'تحقق من بياناتك.',
      );
    }
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id,display_name,role,avatar_url')
      .eq('id', data.user.id)
      .single();
    setBusy(false);
    if (profileError || !profile)
      return Alert.alert(
        'تعذر تحميل الحساب',
        profileError?.message ?? 'لا يوجد ملف حساب مكتمل.',
      );
    onAuthenticated(profile as SessionProfile);
  };
  return (
    <Screen>
      <View style={styles.auth}>
        <Text style={styles.logo}>جايبلك</Text>
        <Text style={styles.heroTitle}>كل ما تحتاجه، أقرب</Text>
        <Text style={styles.muted}>
          سجّل الدخول للوصول إلى حسابك ولوحة التحكم المناسبة لدورك.
        </Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="البريد الإلكتروني"
          placeholderTextColor={colors.muted}
          autoCapitalize="none"
          keyboardType="email-address"
          style={styles.input}
        />
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="كلمة المرور"
          placeholderTextColor={colors.muted}
          secureTextEntry
          style={styles.input}
        />
        <ActionButton
          label={busy ? 'جارٍ الدخول...' : 'تسجيل الدخول'}
          onPress={() => void submit()}
        />
      </View>
    </Screen>
  );
}

function CustomerHome({ profile }: { profile: SessionProfile }) {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    supabase
      .from('companies')
      .select('id,name,category,province,district,logo_url,cover_url')
      .order('created_at', { ascending: false })
      .limit(30)
      .then(({ data, error }) => {
        if (!alive) return;
        if (error) Alert.alert('تعذر تحميل المتاجر', error.message);
        setCompanies((data ?? []) as Company[]);
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);
  return (
    <Screen>
      <Header title="الرئيسية" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>
          مرحباً، {profile.display_name || 'بك'}
        </Text>
        <Text style={styles.title}>اكتشف متاجرك المفضلة</Text>
        <Text style={styles.muted}>
          بيانات المتاجر المعروضة هنا تأتي مباشرة من Supabase.
        </Text>
        {loading ? (
          <LoadingState />
        ) : companies.length === 0 ? (
          <EmptyState
            title="لا توجد متاجر منشورة"
            detail="عند إضافة متجر حقيقي إلى قاعدة البيانات سيظهر هنا تلقائياً."
          />
        ) : (
          <FlatList
            scrollEnabled={false}
            data={companies}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.list}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                <Text style={styles.muted}>
                  {[item.category, item.district, item.province]
                    .filter(Boolean)
                    .join(' · ') || 'معلومات الموقع غير متاحة'}
                </Text>
              </View>
            )}
          />
        )}
      </ScrollView>
    </Screen>
  );
}
function ExploreScreen() {
  const [query, setQuery] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    supabase
      .from('products')
      .select('id,name,price,category,company_id,publication_status')
      .eq('publication_status', 'published')
      .gt('quantity', 0)
      .order('created_at', { ascending: false })
      .limit(40)
      .then(({ data }) => {
        if (alive) {
          setProducts((data ?? []) as Product[]);
          setLoading(false);
        }
      });
    return () => {
      alive = false;
    };
  }, []);
  const filtered = useMemo(
    () =>
      products.filter(item =>
        `${item.name} ${item.category ?? ''}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [products, query],
  );
  return (
    <Screen>
      <Header title="استكشف" />
      <TextInput
        value={query}
        onChangeText={setQuery}
        placeholder="ابحث عن منتج..."
        placeholderTextColor={colors.muted}
        style={styles.search}
      />
      {loading ? (
        <LoadingState />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="لا توجد نتائج"
          detail="جرّب بحثاً آخر أو أضف منتجات منشورة من لوحة التاجر."
        />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.price}>
                {item.price.toLocaleString('ar-IQ')} د.ع
              </Text>
              <Text style={styles.muted}>{item.category || 'بدون تصنيف'}</Text>
            </View>
          )}
        />
      )}
    </Screen>
  );
}
function PlaceholderScreen({
  title,
  detail,
}: {
  title: string;
  detail: string;
}) {
  return (
    <Screen>
      <Header title={title} />
      <EmptyState title={title} detail={detail} />
    </Screen>
  );
}
function CustomerTabs({ profile }: { profile: SessionProfile }) {
  return (
    <Tabs.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.bottom,
        tabBarActiveTintColor: colors.surface,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '500' },
      }}
    >
      <Tabs.Screen name="الرئيسية">
        {() => <CustomerHome profile={profile} />}
      </Tabs.Screen>
      <Tabs.Screen name="استكشف" component={ExploreScreen} />
      <Tabs.Screen name="الرسائل">
        {() => (
          <PlaceholderScreen
            title="الرسائل"
            detail="ستظهر محادثاتك الحقيقية هنا عند توفرها في Supabase."
          />
        )}
      </Tabs.Screen>
      <Tabs.Screen name="المخزون">
        {() => (
          <PlaceholderScreen
            title="المخزون"
            detail="المخزون متاح من لوحة التاجر للحسابات المصرح لها."
          />
        )}
      </Tabs.Screen>
      <Tabs.Screen name="حسابي">
        {() => (
          <PlaceholderScreen
            title="حسابي"
            detail="إعدادات الحساب والهوية ستُقرأ من ملفك في Supabase."
          />
        )}
      </Tabs.Screen>
    </Tabs.Navigator>
  );
}
function MerchantDashboard({ profile }: { profile: SessionProfile }) {
  const [company, setCompany] = useState<Company | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    (async () => {
      const { data: c } = await supabase
        .from('companies')
        .select('id,name,category,province,district,logo_url,cover_url')
        .eq('owner_id', profile.id)
        .maybeSingle();
      if (!alive) return;
      setCompany(c as Company | null);
      if (c) {
        const { data: p } = await supabase
          .from('products')
          .select('id,name,price,category,company_id,publication_status')
          .eq('company_id', c.id)
          .order('created_at', { ascending: false });
        if (alive) setProducts((p ?? []) as Product[]);
      }
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [profile.id]);
  return (
    <Screen>
      <Header title="لوحة التاجر" />
      {loading ? (
        <LoadingState />
      ) : !company ? (
        <EmptyState
          title="لم يتم إنشاء متجر بعد"
          detail="أنشئ شركة حقيقية من لوحة التاجر لتبدأ إدارة المنتجات."
        />
      ) : (
        <ScrollView>
          <Text style={styles.title}>{company.name}</Text>
          <Text style={styles.muted}>{company.category || 'بدون تصنيف'}</Text>
          <View style={styles.metrics}>
            <View style={styles.metric}>
              <Text style={styles.metricValue}>{products.length}</Text>
              <Text style={styles.muted}>المنتجات</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricValue}>
                {
                  products.filter(p => p.publication_status === 'published')
                    .length
                }
              </Text>
              <Text style={styles.muted}>المنشور</Text>
            </View>
          </View>
          <Text style={styles.section}>منتجاتك</Text>
          {products.length === 0 ? (
            <EmptyState
              title="لا توجد منتجات"
              detail="أضف أول منتج حقيقي من لوحة التاجر."
            />
          ) : (
            products.map(p => (
              <View style={styles.card} key={p.id}>
                <Text style={styles.cardTitle}>{p.name}</Text>
                <Text style={styles.price}>
                  {p.price.toLocaleString('ar-IQ')} د.ع
                </Text>
              </View>
            ))
          )}
        </ScrollView>
      )}
    </Screen>
  );
}
function AdminDashboard() {
  const [count, setCount] = useState<number | null>(null);
  useEffect(() => {
    supabase
      .from('profiles')
      .select('id', { count: 'exact', head: true })
      .then(({ count: total }) => setCount(total ?? 0));
  }, []);
  return (
    <Screen>
      <Header title="لوحة الإدارة" />
      {count === null ? (
        <LoadingState />
      ) : (
        <View>
          <Text style={styles.title}>منصة جايبلك</Text>
          <Text style={styles.muted}>
            هذه المساحة تظهر فقط للحسابات الإدارية المصرح لها.
          </Text>
          <View style={styles.metrics}>
            <View style={styles.metric}>
              <Text style={styles.metricValue}>{count}</Text>
              <Text style={styles.muted}>حسابات حقيقية</Text>
            </View>
          </View>
        </View>
      )}
    </Screen>
  );
}
export default function App() {
  const [profile, setProfile] = useState<SessionProfile | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      if (!data.session) return setLoading(false);
      const { data: row } = await supabase
        .from('profiles')
        .select('id,display_name,role,avatar_url')
        .eq('id', data.session.user.id)
        .single();
      setProfile(row as SessionProfile | null);
      setLoading(false);
    });
  }, []);
  if (loading)
    return (
      <Screen>
        <LoadingState />
      </Screen>
    );
  if (!profile) return <AuthScreen onAuthenticated={setProfile} />;
  return (
    <NavigationContainer>
      <Root.Navigator screenOptions={{ headerShown: false }}>
        <Root.Screen
          name={
            profile.role === 'merchant'
              ? 'Merchant'
              : profile.role === 'admin'
              ? 'Admin'
              : 'Customer'
          }
        >
          {() =>
            profile.role === 'merchant' ? (
              <MerchantDashboard profile={profile} />
            ) : profile.role === 'admin' ? (
              <AdminDashboard />
            ) : (
              <CustomerTabs profile={profile} />
            )
          }
        </Root.Screen>
      </Root.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  auth: { flex: 1, justifyContent: 'center', gap: 14 },
  logo: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
    textAlign: 'right',
  },
  heroTitle: {
    color: colors.primary,
    fontSize: typography.hero,
    lineHeight: 44,
    fontWeight: '700',
    textAlign: 'right',
  },
  title: {
    color: colors.primary,
    fontSize: typography.title,
    lineHeight: 28,
    fontWeight: '700',
    textAlign: 'right',
    marginBottom: 8,
  },
  eyebrow: {
    color: colors.muted,
    fontSize: typography.label,
    textAlign: 'right',
    marginBottom: 4,
  },
  muted: {
    color: colors.muted,
    fontSize: typography.body,
    lineHeight: 22,
    textAlign: 'right',
  },
  input: {
    height: 52,
    borderRadius: 18,
    backgroundColor: colors.surface,
    paddingHorizontal: 16,
    color: colors.primary,
    textAlign: 'right',
    borderWidth: 1,
    borderColor: colors.border,
  },
  search: {
    height: 52,
    borderRadius: 18,
    backgroundColor: colors.surface,
    paddingHorizontal: 16,
    color: colors.primary,
    textAlign: 'right',
    borderWidth: 1,
    borderColor: colors.border,
  },
  list: { gap: spacing.gap, paddingTop: 18, paddingBottom: 100 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 24,
    padding: 18,
    marginVertical: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardTitle: {
    color: colors.primary,
    fontSize: typography.title,
    fontWeight: '700',
    textAlign: 'right',
    marginBottom: 4,
  },
  price: {
    color: colors.primary,
    fontSize: typography.price,
    fontWeight: '700',
    textAlign: 'right',
    marginTop: 8,
  },
  bottom: {
    height: 84,
    paddingTop: 10,
    paddingBottom: 10,
    borderTopWidth: 0,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    backgroundColor: colors.primary,
    position: 'absolute',
  },
  metrics: { flexDirection: 'row-reverse', gap: 8, marginVertical: 24 },
  metric: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 24,
    padding: 18,
    alignItems: 'center',
  },
  metricValue: { color: colors.primary, fontSize: 24, fontWeight: '700' },
  section: {
    color: colors.primary,
    fontSize: typography.title,
    fontWeight: '700',
    textAlign: 'right',
    marginBottom: 8,
  },
});
